2233|sales     
9876|production
5678|marketing 
2365|personnel 
5423|admin
