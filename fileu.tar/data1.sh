2233|a.k. shukla      |g.m.     |sales     |12/12/52|6000
9876|jal sharma       |director |production|12/03/50]7000
5678|sumit chakrobarty|d.g.m.   |marketing |19/04/43|6000
2365|barun sengupta   |director |personnel |11/05/47|7800
2365|barun sengupta   |director |personnel |11/05/47|7800
