2233|a.k. shukla      |g.m.     |sales     |12/12/52|6000
9876|jal sharma       |director |production|12/03/50]7000
5678|sumit chakrobarty|d.g.m.   |marketing |19/04/43|6000
2365|barun sengupta   |director |personnel |11/05/47|7800
5423|n.k. gupta       |chairman |admin     |30/08/56|5400
1006|chanchal singhvi |director |sales     |03/09/38|6700
6213|karuna ganguly   |g.m.     |accounts  |05/06/62|6300
1265|s.n. dasgupta    |manager  |sales     |12/09/63|5600
4290|jayant Choudhury |executive|production|07/09/50|6000
2476|anil aggarwal    |manager  |sales     |01/05/59|5000
6521|lalit chowdury   |director |marketing |26/09/40|8200
3212|shyam saksena    |d.g.m.   |accounts  |12/12/55|6000
3564|sudhir Agarwal   |executive|personnel |06/07/47|7500
2345|j.b. saxena      |g.m.     |marketing |12/03/45|8000
0110|v.k. agrawal     |g.m.     |marketing |31/12/40|9000
Amulya nalla
